module.exports = {
  ...require('./PolicyRepository'),
  ...require('./PolicyDetailsRepository'),
  ...require('./ClaimRepository'),
  ...require('./ConversationRepository'),
};
