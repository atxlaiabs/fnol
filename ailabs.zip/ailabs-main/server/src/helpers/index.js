const responseHandler = require('./responseHandler.js');
const common = require('./common.js');

module.exports = {
  ...responseHandler,
  ...common,
};
