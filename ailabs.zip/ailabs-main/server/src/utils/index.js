const constants = require('./constants');
const swaggerConfigs = require('./swaggerConfigs');

module.exports = {
  constants,
  ...swaggerConfigs,
};
