/**
 * Export all the controllers here
 */
exports.Auth = require('./authController');
exports.Policy = require('./policyController');
